#ifndef __LED_H
#define __LED_H

#include "sys.h"

#define LED1 PCout(13)// PC13


extern void Init_LEDpin(void);


#endif


