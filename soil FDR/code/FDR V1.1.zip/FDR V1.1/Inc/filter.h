#ifndef FILTER_H
#define FILTER_H

#include "main.h"

#define N 48  

uint32_t filter(uint32_t seq);  

#endif

