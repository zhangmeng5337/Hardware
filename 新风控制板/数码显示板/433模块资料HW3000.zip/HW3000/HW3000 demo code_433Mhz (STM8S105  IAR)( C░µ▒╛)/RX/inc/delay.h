#ifndef _DELAY_H_
#define _DELAY_H_

extern void m928_delay(uint16_t time_delay);

#endif

