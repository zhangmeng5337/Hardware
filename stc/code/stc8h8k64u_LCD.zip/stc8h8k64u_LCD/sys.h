#ifndef SYS_H_
#define SYS_H_
#include "main.h" 
void delay(void);
void delay1(uchar x);
void delay_ms(unsigned int x);
#endif

