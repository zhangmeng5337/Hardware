#ifndef __icm20948analysis__
#define __icm20948analysis__



signed char Icm20948Init(void);


#endif
