#ifndef __delay__
#define __delay__



void delay_ms(unsigned int t);
void delay_us(unsigned int t);

#endif
