# icm20948-i2c
The project still needs improvement.
