allwinner-tools
===============

awusb
=====
Allwinner's USB driver used by proprietary LiveSuit for Linux.
