
# RM3100.X
 - A simple driver for RM3100 PNI Geomagnetic Sensor. 
 - Tested with a PIC32MX795F512L.
 - I2C communication.
 
## Usage
 For general use. Only has to be adapted to specific microcontroller.
 
## Contributing
You are very welcome to contribute by opening a pull request.

## Documentation
 Doxygen generated doc.
