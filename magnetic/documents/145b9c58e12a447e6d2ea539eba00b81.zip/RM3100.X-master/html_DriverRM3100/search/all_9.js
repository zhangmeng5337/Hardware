var searchData=
[
  ['i2c_20generic_20driver',['I2C generic Driver',['../group___i2_c.html',1,'']]],
  ['i2c_2ec',['i2c.c',['../i2c_8c.html',1,'']]],
  ['i2c_2eh',['i2c.h',['../i2c_8h.html',1,'']]],
  ['i2c_5finit',['i2c_init',['../group___i2_c.html#ga739e721ceab912fd22c86bf411409d7f',1,'i2c.c']]],
  ['i2c_5fread',['i2c_read',['../group___i2_c.html#gac2d47e7a6c76f93f9b537c31a2986e7b',1,'i2c.c']]],
  ['i2c_5fwrite',['i2c_write',['../group___i2_c.html#gac0f145afe8d662af199043939f4398d6',1,'i2c.c']]],
  ['i2cmode',['i2cmode',['../group___i2_c.html#ga7cc695d3e37fd6746cf26bce23fb9891',1,'i2c.h']]]
];
