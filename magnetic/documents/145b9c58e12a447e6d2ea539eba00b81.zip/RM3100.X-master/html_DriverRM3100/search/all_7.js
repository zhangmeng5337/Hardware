var searchData=
[
  ['gain',['gain',['../group___r_m3100.html#gaca3852dab23cf0066809ecc1997fb58b',1,'config']]],
  ['get_5ftime',['get_time',['../main_8c.html#af137ea836b775ca54abbba1d8148b43c',1,'main.c']]],
  ['getdatareadystatus',['getDataReadyStatus',['../group___r_m3100.html#ga83b507ff792e1e99f3a802c4a2211d2c',1,'rm3100.c']]],
  ['getinstructionclock',['GetInstructionClock',['../hardware_8h.html#a450d95819e5184befaec71050a61dce9',1,'hardware.h']]],
  ['getmenuchoice',['GetMenuChoice',['../uart_8c.html#acbe61f9e0d7bcaf719422c36789f886c',1,'GetMenuChoice(void):&#160;uart.c'],['../uart_8h.html#acbe61f9e0d7bcaf719422c36789f886c',1,'GetMenuChoice(void):&#160;uart.c']]],
  ['getperipheralclock',['GetPeripheralClock',['../hardware_8h.html#a1b199a0aedb00251513eb57552f738b4',1,'hardware.h']]],
  ['getrm3100cyclecount',['getRM3100CycleCount',['../group___r_m3100.html#ga0af6ff0ff4e7831329b96325c6857df4',1,'rm3100.c']]],
  ['getrm3100gain',['getRM3100Gain',['../group___r_m3100.html#ga4b9ca5e8c641e4187ae64c2dc791d5d1',1,'rm3100.c']]],
  ['getrm3100maxdatarate',['getRM3100MaxDataRate',['../group___r_m3100.html#ga11c23cb09e4568d4c2b646c9f0e10486',1,'rm3100.c']]],
  ['getrm3100revision',['getRM3100revision',['../group___r_m3100.html#ga5d2d689b6de62e947b9ce6cb94b372c7',1,'rm3100.c']]],
  ['getrm3100samplerate',['getRM3100SampleRate',['../group___r_m3100.html#gacf21399b300ffcd51c41dcf4d91c1d40',1,'rm3100.c']]],
  ['getrm3100status',['getRM3100Status',['../group___r_m3100.html#ga69fa424e233f5f87ec37d1a690d7378e',1,'rm3100.c']]]
];
