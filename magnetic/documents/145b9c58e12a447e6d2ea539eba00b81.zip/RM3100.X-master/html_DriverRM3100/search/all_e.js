var searchData=
[
  ['pbclk',['PBCLK',['../hardware_8h.html#aac23c0047c8aba00b8c269fc2a181959',1,'hardware.h']]],
  ['pi',['PI',['../main_8c.html#a598a3330b3c21701223ee0ca14316eca',1,'main.c']]],
  ['poll_5freg',['POLL_REG',['../group___r_m3100.html#ga34d6c04aa92b2e51300f7495a60a737f',1,'rm3100.h']]]
];
