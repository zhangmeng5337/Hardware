var searchData=
[
  ['mag_5fext_5fcal',['MAG_EXT_CAL',['../main_8c.html#ae82abdb43f3a0c39dcb486f216e5ef63',1,'main.c']]],
  ['mpu_5fi2c',['MPU_I2C',['../hardware_8h.html#a2af56c7528702387df31ab2edd0315b8',1,'hardware.h']]],
  ['ms_5fto_5fcore_5fticks',['MS_TO_CORE_TICKS',['../hardware_8h.html#ac26e7408dc9da77f22ea1c1dbfaa3bd8',1,'hardware.h']]]
];
