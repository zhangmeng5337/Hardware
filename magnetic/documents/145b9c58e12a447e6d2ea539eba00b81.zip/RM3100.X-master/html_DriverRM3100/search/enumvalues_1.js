var searchData=
[
  ['slave',['SLAVE',['../group___i2_c.html#gga7cc695d3e37fd6746cf26bce23fb9891acb616235f3e84323e870be70b278ac7f',1,'i2c.h']]]
];
