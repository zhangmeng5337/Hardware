var searchData=
[
  ['new_5fdata',['new_data',['../main_8c.html#ac385393442990e1256a159d739768c64',1,'main.c']]]
];
