var searchData=
[
  ['brg',['BRG',['../hardware_8h.html#a7469d8cd84e6e02bc55c6f076db607ba',1,'hardware.h']]],
  ['byteptr',['BYTEPTR',['../hardware_8h.html#ab3fd017b2d6a34e3ae23239d528bfdee',1,'hardware.h']]]
];
