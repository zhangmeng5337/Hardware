var searchData=
[
  ['one_5fsecond',['ONE_SECOND',['../hardware_8h.html#ac93edbf7e8fdbf7398453d51bbd37a97',1,'hardware.h']]]
];
