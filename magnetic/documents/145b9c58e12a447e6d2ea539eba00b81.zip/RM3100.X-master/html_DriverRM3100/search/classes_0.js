var searchData=
[
  ['config',['config',['../structconfig.html',1,'']]]
];
