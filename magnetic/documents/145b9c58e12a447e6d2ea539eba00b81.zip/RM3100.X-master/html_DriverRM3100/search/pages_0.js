var searchData=
[
  ['license',['License',['../license.html',1,'']]]
];
