var searchData=
[
  ['uart_20communications',['UART Communications',['../group__uart.html',1,'']]]
];
