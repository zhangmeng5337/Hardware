var searchData=
[
  ['i2c_5finit',['i2c_init',['../group___i2_c.html#ga739e721ceab912fd22c86bf411409d7f',1,'i2c.c']]],
  ['i2c_5fread',['i2c_read',['../group___i2_c.html#gac2d47e7a6c76f93f9b537c31a2986e7b',1,'i2c.c']]],
  ['i2c_5fwrite',['i2c_write',['../group___i2_c.html#gac0f145afe8d662af199043939f4398d6',1,'i2c.c']]]
];
