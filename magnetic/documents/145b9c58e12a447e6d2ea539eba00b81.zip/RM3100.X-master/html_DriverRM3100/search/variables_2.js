var searchData=
[
  ['mag_5fcal_5fmatrix',['mag_cal_matrix',['../main_8c.html#acffc5ec87ab672ab749c17bb5e43ad35',1,'main.c']]],
  ['mag_5foffsets',['mag_offsets',['../main_8c.html#a4aa0622d91ae7d3fb6eacf6fc3d3d607',1,'main.c']]],
  ['max_5fdata_5frate',['max_data_rate',['../group___r_m3100.html#ga44c26ccde6e6ef7e3638e6ad94eff5a7',1,'config']]]
];
