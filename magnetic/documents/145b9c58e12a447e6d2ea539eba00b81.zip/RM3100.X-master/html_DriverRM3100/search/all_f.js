var searchData=
[
  ['readrm3100raw',['ReadRM3100Raw',['../group___r_m3100.html#ga4bc9cb1dc86b4491b367c864bf169224',1,'rm3100.c']]],
  ['requestsinglemeasurement',['requestSingleMeasurement',['../group___r_m3100.html#ga8d8c6e4cc8eeaa53c4e9c9048e7e28ab',1,'rm3100.c']]],
  ['reset_5ftimer',['reset_timer',['../main_8c.html#af732b8dd1eccf042f07378cc93bdc63f',1,'main.c']]],
  ['revid_5freg',['REVID_REG',['../group___r_m3100.html#gaee7dac3e4de5414b1c21aad19b19ffa2',1,'rm3100.h']]],
  ['rm',['rm',['../group___r_m3100.html#ga9d6ca957f471c418abcd697e513df5f9',1,'rm3100.c']]],
  ['rm3100_20driver',['RM3100 Driver',['../group___r_m3100.html',1,'']]],
  ['rm3100_2ec',['rm3100.c',['../rm3100_8c.html',1,'']]],
  ['rm3100_2eh',['rm3100.h',['../rm3100_8h.html',1,'']]],
  ['rm3100_5faddress_5f00',['RM3100_ADDRESS_00',['../group___r_m3100.html#ga507d213518d205e642189f44e2cb7b32',1,'rm3100.h']]],
  ['rm3100_5faddress_5f01',['RM3100_ADDRESS_01',['../group___r_m3100.html#ga86ea3bbeec97b139e094f28077c1718f',1,'rm3100.h']]],
  ['rm3100_5faddress_5f10',['RM3100_ADDRESS_10',['../group___r_m3100.html#ga59a9607ed5067a85d4a0bae530e69840',1,'rm3100.h']]],
  ['rm3100_5faddress_5f11',['RM3100_ADDRESS_11',['../group___r_m3100.html#ga18207a3c927119ca33e5b8210c311f1c',1,'rm3100.h']]],
  ['rm3100_5finit_5fcmm_5foperation',['RM3100_init_CMM_Operation',['../group___r_m3100.html#gabdec1fca545c4916207fb747e0249f5e',1,'rm3100.c']]],
  ['rm3100_5finit_5fsm_5foperation',['RM3100_init_SM_Operation',['../group___r_m3100.html#gaf9eec6f547ec46f5bb788404606e48fa',1,'rm3100.c']]]
];
