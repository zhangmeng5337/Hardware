var searchData=
[
  ['sample_5frate',['sample_rate',['../group___r_m3100.html#ga63433fe701b4e06f2cfdd50509e660db',1,'config']]],
  ['senddatabuffer',['SendDataBuffer',['../uart_8c.html#a5a8905bd9a24804b60f84783fad77953',1,'SendDataBuffer(const char *buffer, UINT32 size):&#160;uart.c'],['../uart_8h.html#a5a8905bd9a24804b60f84783fad77953',1,'SendDataBuffer(const char *buffer, UINT32 size):&#160;uart.c']]],
  ['sensor_5fxyz',['sensor_xyz',['../structsensor__xyz.html',1,'']]],
  ['setcmmdatarate',['setCMMdatarate',['../group___r_m3100.html#gaac0affb5360511fb1b5f66826dcae0e4',1,'rm3100.c']]],
  ['setcyclecount',['setCycleCount',['../group___r_m3100.html#gaf8d916ad29725536313f617077aecb44',1,'rm3100.c']]],
  ['slave',['SLAVE',['../group___i2_c.html#gga7cc695d3e37fd6746cf26bce23fb9891acb616235f3e84323e870be70b278ac7f',1,'i2c.h']]],
  ['sm_5fall_5faxis',['SM_ALL_AXIS',['../group___r_m3100.html#ga673992ba3521f671f9004829776c9c1b',1,'rm3100.h']]],
  ['status_5fmask',['STATUS_MASK',['../group___r_m3100.html#gaeb86657b890e53489f6178591bbd5b97',1,'rm3100.h']]],
  ['status_5freg',['STATUS_REG',['../group___r_m3100.html#ga1f7e79cfe81dc06414550fa52418941e',1,'rm3100.h']]],
  ['ste_5foff',['STE_OFF',['../group___r_m3100.html#ga3a58f52d6d857ed5af9b6a220643ad3d',1,'rm3100.h']]],
  ['ste_5fon',['STE_ON',['../group___r_m3100.html#ga24fc9c1e9b47bbe21cdeff2500ca0f88',1,'rm3100.h']]],
  ['sys_5ffreq',['SYS_FREQ',['../hardware_8h.html#a7d5ce7b79462bbfb630ee53075540b65',1,'hardware.h']]]
];
