var searchData=
[
  ['senddatabuffer',['SendDataBuffer',['../uart_8c.html#a5a8905bd9a24804b60f84783fad77953',1,'SendDataBuffer(const char *buffer, UINT32 size):&#160;uart.c'],['../uart_8h.html#a5a8905bd9a24804b60f84783fad77953',1,'SendDataBuffer(const char *buffer, UINT32 size):&#160;uart.c']]],
  ['setcmmdatarate',['setCMMdatarate',['../group___r_m3100.html#gaac0affb5360511fb1b5f66826dcae0e4',1,'rm3100.c']]],
  ['setcyclecount',['setCycleCount',['../group___r_m3100.html#gaf8d916ad29725536313f617077aecb44',1,'rm3100.c']]]
];
