var searchData=
[
  ['senddatabuffer',['SendDataBuffer',['../uart_8c.html#a5a8905bd9a24804b60f84783fad77953',1,'SendDataBuffer(const char *buffer, UINT32 size):&#160;uart.c'],['../uart_8h.html#a5a8905bd9a24804b60f84783fad77953',1,'SendDataBuffer(const char *buffer, UINT32 size):&#160;uart.c']]],
  ['setcmmdatarate',['setCMMdatarate',['../group___r_m3100.html#gaac0affb5360511fb1b5f66826dcae0e4',1,'rm3100.c']]],
  ['setcyclecount',['setCycleCount',['../group___r_m3100.html#gaf8d916ad29725536313f617077aecb44',1,'rm3100.c']]],
  ['spiget',['spiGet',['../_m_r_f24_j40_8c.html#a4fc215089380e1e05b3e238131117a07',1,'MRF24J40.c']]],
  ['spiput',['spiPut',['../_m_r_f24_j40_8c.html#adf2c40514add13b12ce8ee4f884cdeeb',1,'MRF24J40.c']]]
];
