var searchData=
[
  ['getinstructionclock',['GetInstructionClock',['../hardware_8h.html#a450d95819e5184befaec71050a61dce9',1,'hardware.h']]],
  ['getperipheralclock',['GetPeripheralClock',['../hardware_8h.html#a1b199a0aedb00251513eb57552f738b4',1,'hardware.h']]]
];
