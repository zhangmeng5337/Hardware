var searchData=
[
  ['uart_5fmodule_5fid',['UART_MODULE_ID',['../uart_8h.html#aca4944b53d55e9c09a2f77defebe54e1',1,'uart.h']]],
  ['uartbaudrate',['UARTBAUDRATE',['../hardware_8h.html#adb8b1400222734a6c41dea4510b98e22',1,'hardware.h']]],
  ['us_5fto_5fcore_5fticks',['uS_TO_CORE_TICKS',['../hardware_8h.html#ac782fe4fb621a44c90455332b9bc0b92',1,'hardware.h']]]
];
