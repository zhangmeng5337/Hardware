var searchData=
[
  ['gain',['gain',['../group___r_m3100.html#gaca3852dab23cf0066809ecc1997fb58b',1,'config']]]
];
