var searchData=
[
  ['readrm3100raw',['ReadRM3100Raw',['../group___r_m3100.html#ga4bc9cb1dc86b4491b367c864bf169224',1,'rm3100.c']]],
  ['requestsinglemeasurement',['requestSingleMeasurement',['../group___r_m3100.html#ga8d8c6e4cc8eeaa53c4e9c9048e7e28ab',1,'rm3100.c']]],
  ['reset_5ftimer',['reset_timer',['../main_8c.html#af732b8dd1eccf042f07378cc93bdc63f',1,'main.c']]],
  ['rm3100_5finit_5fcmm_5foperation',['RM3100_init_CMM_Operation',['../group___r_m3100.html#gabdec1fca545c4916207fb747e0249f5e',1,'rm3100.c']]],
  ['rm3100_5finit_5fsm_5foperation',['RM3100_init_SM_Operation',['../group___r_m3100.html#gaf9eec6f547ec46f5bb788404606e48fa',1,'rm3100.c']]]
];
