var searchData=
[
  ['master',['MASTER',['../group___i2_c.html#gga7cc695d3e37fd6746cf26bce23fb9891ae5807df697b52e8b944bf598cabadb3a',1,'i2c.h']]]
];
