# arduino_SevenSegment
Arduino Seven Segment display driver for displays using the HT16K33

This library can be used with Adafruit's 7-segmet LED backpacks
It was written to provide s smaller, faster and (for me) more convenient driver

If you have any comments or remarks, please contact me at Joeri@Joserta.be
