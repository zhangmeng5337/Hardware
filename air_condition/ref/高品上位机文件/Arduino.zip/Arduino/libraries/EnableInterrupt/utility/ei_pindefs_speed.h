#ifdef INTERRUPT_FLAG_PIN0
volatile uint8_t INTERRUPT_FLAG_PIN0 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN1
volatile uint8_t INTERRUPT_FLAG_PIN1 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN2
volatile uint8_t INTERRUPT_FLAG_PIN2 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN3
volatile uint8_t INTERRUPT_FLAG_PIN3 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN4
volatile uint8_t INTERRUPT_FLAG_PIN4 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN5
volatile uint8_t INTERRUPT_FLAG_PIN5 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN6
volatile uint8_t INTERRUPT_FLAG_PIN6 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN7
volatile uint8_t INTERRUPT_FLAG_PIN7 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN8
volatile uint8_t INTERRUPT_FLAG_PIN8 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN9
volatile uint8_t INTERRUPT_FLAG_PIN9 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN10
volatile uint8_t INTERRUPT_FLAG_PIN10 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN11
volatile uint8_t INTERRUPT_FLAG_PIN11 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN12
volatile uint8_t INTERRUPT_FLAG_PIN12 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN13
volatile uint8_t INTERRUPT_FLAG_PIN13 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN14
volatile uint8_t INTERRUPT_FLAG_PIN14 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN15
volatile uint8_t INTERRUPT_FLAG_PIN15 = 0;
#endif

#ifdef INTERRUPT_FLAG_PIN18
volatile uint8_t INTERRUPT_FLAG_PIN18 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN19
volatile uint8_t INTERRUPT_FLAG_PIN19 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN20
volatile uint8_t INTERRUPT_FLAG_PIN20 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN21
volatile uint8_t INTERRUPT_FLAG_PIN21 = 0;
#endif

#ifdef INTERRUPT_FLAG_PINA0
volatile uint8_t INTERRUPT_FLAG_PINA0 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA1
volatile uint8_t INTERRUPT_FLAG_PINA1 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA2
volatile uint8_t INTERRUPT_FLAG_PINA2 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA3
volatile uint8_t INTERRUPT_FLAG_PINA3 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA4
volatile uint8_t INTERRUPT_FLAG_PINA4 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA5
volatile uint8_t INTERRUPT_FLAG_PINA5 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA8
volatile uint8_t INTERRUPT_FLAG_PINA8 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA9
volatile uint8_t INTERRUPT_FLAG_PINA9 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA10
volatile uint8_t INTERRUPT_FLAG_PINA10 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA11
volatile uint8_t INTERRUPT_FLAG_PINA11 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA12
volatile uint8_t INTERRUPT_FLAG_PINA12 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA13
volatile uint8_t INTERRUPT_FLAG_PINA13 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA14
volatile uint8_t INTERRUPT_FLAG_PINA14 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINA15
volatile uint8_t INTERRUPT_FLAG_PINA15 = 0;
#endif
#ifdef INTERRUPT_FLAG_PINSS
volatile uint8_t INTERRUPT_FLAG_PINSS = 0;
#endif
#ifdef INTERRUPT_FLAG_PINSCK
volatile uint8_t INTERRUPT_FLAG_PINSCK = 0;
#endif
#ifdef INTERRUPT_FLAG_PINMOSI
volatile uint8_t INTERRUPT_FLAG_PINMOSI = 0;
#endif
#ifdef INTERRUPT_FLAG_PINMISO
volatile uint8_t INTERRUPT_FLAG_PINMISO = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN70
volatile uint8_t INTERRUPT_FLAG_PIN70 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN71
volatile uint8_t INTERRUPT_FLAG_PIN71 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN72
volatile uint8_t INTERRUPT_FLAG_PIN72 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN73
volatile uint8_t INTERRUPT_FLAG_PIN73 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN74
volatile uint8_t INTERRUPT_FLAG_PIN74 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN75
volatile uint8_t INTERRUPT_FLAG_PIN75 = 0;
#endif
#ifdef INTERRUPT_FLAG_PIN76
volatile uint8_t INTERRUPT_FLAG_PIN76 = 0;
#endif
