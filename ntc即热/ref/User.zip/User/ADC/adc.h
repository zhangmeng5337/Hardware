#ifndef __ADC_H
#define __ADC_H

#include "stm32f10x.h"

#define ADCx_GPIO_CLK					RCC_APB2Periph_GPIOA
#define ADCx_DMA_CLk					RCC_AHBPeriph_DMA1

#define ADCx_CLK							RCC_APB2Periph_ADC1
#define ADC_x									ADC1

// ADC1 ��Ӧ DMA1 ͨ�� 1�� ADC3 ��Ӧ DMA2 ͨ�� 5�� ADC2 û�� DMA ����
#define ADC_DMA_CHANNEL				DMA1_Channel1

#define ADCx_Channel_1_PORT		GPIOA
#define ADCx_Channel_1_PIN		GPIO_Pin_5
#define ADCx_Channel_1				ADC_Channel_5


#define ADCx_Channel_3_PORT		GPIOA
#define ADCx_Channel_3_PIN		GPIO_Pin_7
#define ADCx_Channel_3				ADC_Channel_7


void ADCx_Mode_Init(void);
uint8_t Get_Temperature(void);
float Get_Precent(void);

#endif /* __ADC_H */

