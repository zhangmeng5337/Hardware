#ifndef __KEY_H_
#define __KEY_H_

#include "stm32f10x.h"
#include "./sysTick/sysTick.h"

#define KEY_GPIO_APBx_ClkCmd		RCC_APB2PeriphClockCmd
#define KEY_GPIO_CLK						RCC_APB2Periph_GPIOA

/* KEY1 PA10 */
#define KEY1_GPIO_PORT					GPIOA
#define KEY1_GPIO_PIN						GPIO_Pin_10

/* KEY2 PA11 */
#define KEY2_GPIO_PORT					GPIOA
#define KEY2_GPIO_PIN						GPIO_Pin_11


#define KEY1		GPIO_ReadInputDataBit(KEY1_GPIO_PORT,KEY1_GPIO_PIN)
#define KEY2		GPIO_ReadInputDataBit(KEY2_GPIO_PORT,KEY2_GPIO_PIN)

#define KEY1_ON			1
#define KEY2_ON			2

//�Ƿ���ˮ���
#define WATER_GPIO_APBx_ClkCmd		RCC_APB2PeriphClockCmd
#define WATER_GPIO_CLK						RCC_APB2Periph_GPIOA

/* WATER PA12 */
#define WATER_GPIO_PORT						GPIOA
#define WATER_GPIO_PIN						GPIO_Pin_12

#define WATER		GPIO_ReadInputDataBit(WATER_GPIO_PORT,WATER_GPIO_PIN)

void KEY_Config(void);
uint8_t KEY_Scan(uint8_t mode);
void Water_Detect(void);

#endif	/* __KEY_H_ */

