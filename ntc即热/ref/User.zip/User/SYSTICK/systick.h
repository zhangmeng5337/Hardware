#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32f10x.h"

extern uint32_t clock_array[5];

void Systick_Init(void);
void delay_ms(uint32_t ms);

#endif /* __SYSTICK_H */

