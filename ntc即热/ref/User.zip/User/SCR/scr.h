#ifndef __SCR_H_
#define __SCR_H_

#include "stm32f10x.h"

#define SCR_ON()	GPIO_SetBits(GPIOB,GPIO_Pin_0);
#define SCR_OFF()	GPIO_ResetBits(GPIOB,GPIO_Pin_0);

void SCR_GPIO_Init(void);

#endif /* __SCR_H_ */

