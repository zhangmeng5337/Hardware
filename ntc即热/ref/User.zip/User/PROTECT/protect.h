#ifndef __PROTECT_H_
#define __PROTECT_H_

#include "stm32f10x.h"

//��������ѡ����Data0�ڵı�־λ����
#define DATA_FLAG		0xa8

void Read_Protect(void);
void Read_Protect_Erase(void);
void Write_Protect(void);
void Write_Protect_Erase(void);
void WriteFlag_to_OptionData0(void);
uint8_t ReadFlag_from_OptionData0(void);
void Read_Protect_Check(void);

#endif /* __PROTECT_H_ */


