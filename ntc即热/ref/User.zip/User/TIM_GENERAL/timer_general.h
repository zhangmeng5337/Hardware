#ifndef __TIMER_GENERAL_H
#define __TIMER_GENERAL_H

#include "stm32f10x.h"


//PWM�����ʱ������
#define TIMx_PWM		TIM2

#define TIM_PWM_GPIO_APBx_ClkCmd	RCC_APB2PeriphClockCmd
#define TIM_PWM_GPIO_CLK					RCC_APB2Periph_GPIOA
#define TIM_PWM_APBx_ClkCmd				RCC_APB1PeriphClockCmd
#define TIM_PWM_CLK								RCC_APB1Periph_TIM2

#define TIM_PWM_1_GPIO_PIN		GPIO_Pin_0
#define TIM_PWM_2_GPIO_PIN		GPIO_Pin_1

#define TIM_PWM_1_GPIO_PORT		GPIOA
#define TIM_PWM_2_GPIO_PORT		GPIOA

//�Զ���װ��ֵ
#define TIM_PWM_ARR			(1000-1)
//�ȽϼĴ���ֵ
#define TIM_PWM_CCR			(1000-1)


void TIM_PWN_Config(void);
#endif /* __TIMER_GENERAL_H */


