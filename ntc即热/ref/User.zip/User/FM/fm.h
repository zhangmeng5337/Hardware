#ifndef __FM_H_
#define __FM_H_

#include "stm32f10x.h"

#define FM_ON()		GPIO_SetBits(GPIOA,GPIO_Pin_8);
#define FM_OFF()	GPIO_ResetBits(GPIOA,GPIO_Pin_8);

void FM_GPIO_Config(void);		//��ʼ��GPIO

#endif /*__FM_H_*/
